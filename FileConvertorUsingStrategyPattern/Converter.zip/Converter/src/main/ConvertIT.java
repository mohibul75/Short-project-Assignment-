package main;

import java.io.File;

public interface ConvertIT {
    public void convert(File file) throws Exception;
}
